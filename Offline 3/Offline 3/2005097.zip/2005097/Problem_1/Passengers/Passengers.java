package Problem_1.Passengers;

public interface Passengers {

    void repair();
    void work();
    void login();
    void logout();
}
